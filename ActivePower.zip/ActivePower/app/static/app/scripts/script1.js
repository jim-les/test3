

$(document).ready(function () {
    $("#close_navbar_icon").on("click", function () {
        $(".navbar_ul").css("width", "0");
        $(".navbar_ul").css("visibility", "hidden")

    });
    $(".menu_icon").on("click", function () {
        $(".navbar_ul").css("width", "85%");
        $(".navbar_ul").css("visibility", "visible");

    });
})

function Reset(x) {
    if (x.matches) { // If media query matches
        document.querySelector(".navbar_ul").style.width = "100%";
        document.querySelector(".navbar_ul").style.visibility = "visible";
    }
    else { // If media query matches
        document.querySelector(".navbar_ul").style.width = "0";
    }
}

var x = window.matchMedia("(min-width: 768px)")
Reset(x) // Call listener function at run time
x.addListener(Reset)

