"""
Definition of views.
"""

from datetime import datetime
from django.shortcuts import render
from django.http import HttpResponseBadRequest, HttpRequest, HttpResponseRedirect
from .models import *

def home(request):
    """Renders the home page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/index.html',
        {
            'title':'Home',
            'year':datetime.now().year,
            'logo_icon' : logo_icon.objects.all(),
            'Logos': Logo.objects.all(),
            'Carousels' : Carousel.objects.all(),
            'ourProducts' : Home_Page_OurProducts.objects.all(),
            "aftersales": Aftersales_service.objects.all(),
            "Extra_Images" : Extra_Image.objects.all(),
            "Our_Partnership" : Our_Partnership.objects.all()
        }
    )

def contact(request):
    """Renders the contact page."""
    assert isinstance(request, HttpRequest)
    if request.method == "POST":
        emails = Email(name= request.POST['name'],
                      phone = request.POST['phone'], 
                      email = request.POST['email'], 
                      subject = request.POST['subject'], 
                      message = request.POST['message']
                      )
        emails.save()
        print("message recieved")

    return render(
        request,
        'app/contact.html',
        {
            'title':'Home',
            'year':datetime.now().year,
            'logo_icon' : logo_icon.objects.all(),
            'Logos': Logo.objects.all(),
            'Carousels' : Carousel.objects.all(),
            'ourProducts' : Home_Page_OurProducts.objects.all(),
            "aftersales": Aftersales_service.objects.all(),
            "Extra_Images" : Extra_Image.objects.all(),
            "Our_Partnership" : Our_Partnership.objects.all()
        }
    )


def about(request):
    """Renders the about page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/about.html',
        {
            'title':'About',
            'logo_icon' : logo_icon.objects.all(),
            'message':'Your application description page.',
            'year':datetime.now().year,
            'Logos': Logo.objects.all(),
            "Extra_Images" : Extra_Image.objects.all(),
        }
    )

def products(request):
    """Renders the about page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/product.html',
        {
            'title':'Products',
            'logo_icon' : logo_icon.objects.all(),
            'message':'Your application description page.',
            'year':datetime.now().year,
            'Logos': Logo.objects.all(),
            "Extra_Images" : Extra_Image.objects.all(),
        }
    )

def aftersales(request):
    """Renders the about page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/aftersales.html',
        {
            'title':'Products',
            'logo_icon' : logo_icon.objects.all(),

            'message':'Your application description page.',
            'year':datetime.now().year,
            'Logos': Logo.objects.all(),
            "Extra_Images" : Extra_Image.objects.all(),
        }
    )

def solutions(request):
    """Renders the about page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/solution.html',
        {
            'title':'Products',
            'logo_icon' : logo_icon.objects.all(),

            'message':'Your application description page.',
            'year':datetime.now().year,
            'Logos': Logo.objects.all(),
            "Extra_Images" : Extra_Image.objects.all(),
        }
    )


def members(request):
    """Renders the about page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/members.html',
        {
            'title':'Products',
            'logo_icon' : logo_icon.objects.all(),

            'message':'Your application description page.',
            'year':datetime.now().year,
            'Logos': Logo.objects.all(),
            "Extra_Images" : Extra_Image.objects.all(),
            "Our_Managements" : Our_Management.objects.all(),
        }
    )

def quoteForm(request):
    """Renders the about page."""
    assert isinstance(request, HttpRequest)
    if request.method == "post":
        quote = quote_Form(
                First_Name = request.POST['firtname'],
                Last_Name = request.POST['lastname'],
                Company_Name = request.POST['companynname'],
                Company_Email = request.POST['companyemail'],
                Contact = request.POST['contact'],
                Subject = request.POST['subject'],
                Message = request.POST['message'],
            )
    return render(
        request,
        'app/quote.html',
        {
            'logo_icon' : logo_icon.objects.all(),
            'title':'quote',
            'message':'Your application description page.',
            'year':datetime.now().year,
            'Logos': Logo.objects.all(),
            "Extra_Images" : Extra_Image.objects.all(),
            "Our_Managements" : Our_Management.objects.all(),
        }
    )

def brochure(request):
    """Renders the about page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/brochure.html',
        {
            'logo_icon' : logo_icon.objects.all(),
            'title':'Products',
            'message':'Your application description page.',
            'year':datetime.now().year,
            'Logos': Logo.objects.all(),
            "Extra_Images" : Extra_Image.objects.all(),
            "Our_Managements" : Our_Management.objects.all(),
            "document" : Document.objects.all()
        }
    )
