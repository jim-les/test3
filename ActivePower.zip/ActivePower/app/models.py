"""
Definition of models.
"""

from django.db import models
class logo_icon(models.Model):
    img = models.ImageField(upload_to='Images')

class Logo(models.Model):
    img = models.ImageField(upload_to="Images")

class Carousel(models.Model):
    img = models.ImageField(upload_to="Images")

class Home_Page_OurProducts(models.Model):
    img = models.ImageField(upload_to="Images")
    product_type = models.CharField(max_length=255)
    description = models.TextField()


class Aftersales_service(models.Model):
    icon = models.CharField(max_length=255)
    Service_name = models.CharField(max_length=255)
    Service_info = models.CharField(max_length=255)

class Extra_Image(models.Model):
    Homepage_background_Image = models.ImageField(upload_to="Images")
    About_background_Image = models.ImageField(upload_to="Images")
    Contact_background_Image = models.ImageField(upload_to="Images")
    Products_background_Image = models.ImageField(upload_to="Images")
    Aftersales_background_Image = models.ImageField(upload_to="Images")
    Solutions_background_Image = models.ImageField(upload_to="Images")
    quote_background_Image = models.ImageField(upload_to='Images', null=True)

class Our_Management(models.Model):
    img = models.ImageField(upload_to="Images")
    name = models.CharField(max_length=255)
    position = models.CharField(max_length=255)


class Our_Partnership(models.Model):
    img = models.ImageField(upload_to="Images")

class Email(models.Model):
    name = models.CharField(max_length=255, null=True)
    phone = models.CharField(max_length=255, null=True)
    email = models.CharField(max_length=255, null=True)
    subject = models.CharField(max_length=255, null=True)
    message = models.TextField(null=True)

class quote_Form(models.Model):
    First_Name = models.CharField(max_length=255, null=True)
    Last_Name = models.CharField(max_length=255, null=True)
    Company_Name = models.CharField(max_length=255, null=True)
    Company_Email = models.CharField(max_length=255, null=True)
    Contact = models.CharField(max_length=255, null=True)
    category = models.CharField(max_length=255, null=True)
    Request_product = models.CharField(max_length=255, null=True)
    subject = models.CharField(max_length=255, null=True)
    message = models.TextField(null=True)

class Document(models.Model):
    description = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)