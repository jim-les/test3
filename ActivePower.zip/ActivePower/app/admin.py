from django.contrib import admin
from .models import *

admin.site.register(Logo)
admin.site.register(Carousel)
admin.site.register(Home_Page_OurProducts)
admin.site.register(Aftersales_service)
admin.site.register(Extra_Image)
admin.site.register(Our_Management)
admin.site.register(Our_Partnership)
admin.site.register(Email)
admin.site.register(Document)
admin.site.register(logo_icon)